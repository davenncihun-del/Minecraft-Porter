package demo;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
public class Compat {
  public void init() { MinecraftForge.EVENT_BUS.register(this); }
}
